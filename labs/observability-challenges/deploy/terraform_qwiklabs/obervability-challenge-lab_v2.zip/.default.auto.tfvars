
gcp_project_id = "011y-movie-guru"
locust_py_file="https://raw.githubusercontent.com/MKand/movie-guru/refs/heads/obs_lab/labs/observability-challenges/locust/locustfile.py"
otel_file="https://raw.githubusercontent.com/MKand/movie-guru/refs/heads/obs_lab/utils/metrics/otel.values.yaml"